using MelonLoader;
using Bullet_Train;
[assembly: MelonInfo(typeof(BulletTrain), "Bullet Train", "1.0", "AgiHedvig")]
[assembly: MelonGame("Sad Owl Studios", "Viewfinder")]