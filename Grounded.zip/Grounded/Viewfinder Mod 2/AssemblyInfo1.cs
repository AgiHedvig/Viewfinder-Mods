using MelonLoader;
using Grounded_Mod;
[assembly: MelonInfo(typeof(Grounded), "Grounded", "1.0", "AgiHedvig")]
[assembly: MelonGame("Sad Owl Studios", "Viewfinder")]