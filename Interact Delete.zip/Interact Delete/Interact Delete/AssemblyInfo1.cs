using MelonLoader;
using Interact_Delete;
[assembly: MelonInfo(typeof(InteractDelete), "Interact Delete", "1.0", "AgiHedvig")]
[assembly: MelonGame("Sad Owl Studios", "Viewfinder")]