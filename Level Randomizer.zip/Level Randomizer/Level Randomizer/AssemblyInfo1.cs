using MelonLoader;
using Level_Randomizer;
[assembly: MelonInfo(typeof(LevelRandomizer), "Level Randomizer", "1.0", "AgiHedvig")]
[assembly: MelonGame("Sad Owl Studios", "Viewfinder")]