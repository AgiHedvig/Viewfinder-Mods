using MelonLoader;
using Low_Gravity;
[assembly: MelonInfo(typeof(LowGravity), "Low Gravity", "1.0", "AgiHedvig")]
[assembly: MelonGame("Sad Owl Studios", "Viewfinder")]