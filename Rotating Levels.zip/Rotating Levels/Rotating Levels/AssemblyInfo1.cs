using MelonLoader;
using Rotating_Levels;
[assembly: MelonInfo(typeof(RotatingLevels), "Rotating Levels", "1.0", "AgiHedvig")]
[assembly: MelonGame("Sad Owl Studios", "Viewfinder")]