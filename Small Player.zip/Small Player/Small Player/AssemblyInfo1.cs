using MelonLoader;
using Small_Player;
[assembly: MelonInfo(typeof(SmallPlayer), "Small Player", "1.0", "AgiHedvig")]
[assembly: MelonGame("Sad Owl Studios", "Viewfinder")]